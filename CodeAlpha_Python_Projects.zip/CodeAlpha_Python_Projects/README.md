# CodeAlpha Python Programming Internship Projects

**Intern:** Mujahid Muktar  
**Domain:** Python Programming  
**Student ID:** CA/DF1/436911

This repository contains three beginner-friendly console projects based on the CodeAlpha task sheet:

1. Task 1 — Hangman Game
2. Task 2 — Stock Portfolio Tracker
3. Task 4 — Basic Chatbot

The task sheet says to complete **2 or 3 tasks out of the 4**. These three projects are included so you can submit three, if that is what your coordinator expects.

## Requirements

- Python 3
- No third-party Python packages are required.

Check Python:
```bash
python3 --version
```

## Run each project

From this project folder:

```bash
python3 Task1_Hangman/hangman.py
python3 Task2_Stock_Tracker/stock_tracker.py
python3 Task4_Basic_Chatbot/chatbot.py
```

## Project summaries

### Task 1: Hangman Game
- Chooses one of five predefined words at random.
- The player guesses one letter at a time.
- Allows a maximum of six incorrect guesses.
- Uses `random`, a `while` loop, `if/else`, strings and lists.

### Task 2: Stock Portfolio Tracker
- Accepts stock symbols and quantities from the user.
- Uses a dictionary of example prices defined in the program.
- Calculates the total investment value.
- Offers to save the portfolio to a CSV file.
- The prices are sample values for this programming exercise, not live market prices or investment advice.

### Task 4: Basic Chatbot
- Responds to simple greetings, questions and goodbye messages.
- Uses predefined rules, `if/elif/else`, a function and a loop.

## Before submitting

1. Run all three programs yourself.
2. Try different inputs and make sure each works.
3. Take genuine screenshots of each running program on your computer.
4. Upload the project files to a public GitHub repository named `CodeAlpha_Python_Projects` (or the exact repository name required by your coordinator).
5. Add the GitHub repository link to your LinkedIn project post.
6. Record a short video showing each program running and explaining what it does.
7. Submit the repository/video links through the official CodeAlpha submission form before **20 December 2026**.

Do not claim that you personally tested or recorded anything until you have done those steps.
